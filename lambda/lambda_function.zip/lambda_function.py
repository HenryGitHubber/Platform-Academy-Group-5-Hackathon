import json
import boto3
import codecs
import logging
from datetime import datetime, timezone

logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3 = boto3.client("s3")

# ── Configuration ────────────────────────────────────────────────────────────
RAW_PREFIX = "raw/"
OUTPUT_KEY = "processed/all_data.json"

# Cost per completed module in EUR (from cost_key_data.json)
DEFAULT_COSTS = {
    "skillbuilder": 123.80,
    "instructor": 208.00,
    "mytms": 50.00,
    "game_day": 305.00,
    "hackathon": 0.00,
    "foundational_cert": 150.00,
}

# Normalise inconsistent stream names found in the data
def _to_bool(val) -> bool:
    """Handle True/False booleans, 'TRUE'/'FALSE' strings, and 1/0 integers."""
    if isinstance(val, bool):
        return val
    if isinstance(val, str):
        return val.strip().upper() == "TRUE"
    return bool(val)


STREAM_ALIASES = {
    "datascience": "Data Science",
    "solutions architect": "Solutions Architecture",
    "cloud ops / reliability": "Cloud Operations / Reliability",
    "cloud ops/reliability": "Cloud Operations / Reliability",
}

# ── Helpers ───────────────────────────────────────────────────────────────────

def _read_json(bucket: str, key: str):
    """Download an S3 object and parse JSON, handling UTF-8 BOM."""
    try:
        response = s3.get_object(Bucket=bucket, Key=key)
        raw_bytes = response["Body"].read()
        # Strip UTF-8 BOM if present
        text = raw_bytes.decode("utf-8-sig")
        return json.loads(text)
    except s3.exceptions.NoSuchKey:
        logger.warning("Key not found in S3: %s/%s — skipping", bucket, key)
        return None
    except Exception as exc:
        logger.error("Failed to read %s/%s: %s", bucket, key, exc)
        return None


def _write_json(bucket: str, key: str, data: dict):
    body = json.dumps(data, ensure_ascii=False, default=str)
    s3.put_object(
        Bucket=bucket,
        Key=key,
        Body=body.encode("utf-8"),
        ContentType="application/json",
        CacheControl="no-cache",
    )
    logger.info("Written output to s3://%s/%s", bucket, key)


def _normalise_stream(raw: str | None) -> str:
    if not raw:
        return "Unknown"
    return STREAM_ALIASES.get(raw.strip().lower(), raw.strip())


def _normalise_year(raw) -> int | None:
    try:
        year = int(str(raw).strip())
        return year if year > 2000 else None
    except (ValueError, TypeError):
        return None


def _calculate_cost(cost_record: dict, cost_keys: dict) -> float:
    """Sum up completed module costs for one employee."""
    total = 0.0
    if cost_record.get("skillbuilder_completed"):
        total += cost_keys.get("skillbuilder_cost", DEFAULT_COSTS["skillbuilder"])
    if cost_record.get("instructor_completed"):
        total += cost_keys.get("instructor_cost", DEFAULT_COSTS["instructor"])
    if cost_record.get("mytms_completed"):
        total += cost_keys.get("mytms_cost", DEFAULT_COSTS["mytms"])
    if cost_record.get("game_day_completed"):
        total += cost_keys.get("game_day_cost", DEFAULT_COSTS["game_day"])
    if cost_record.get("hackathon_completed"):
        total += cost_keys.get("hackathon_cost", DEFAULT_COSTS["hackathon"])
    if cost_record.get("completed_cert_voucher"):
        total += cost_keys.get("foundational_cert_cost", DEFAULT_COSTS["foundational_cert"])
    return round(total, 2)


# ── Core processing ────────────────────────────────────────────────────────────

def _load_all_data(bucket: str) -> tuple[list, list, list, dict]:
    """
    Load base files plus any year-specific override files.
    Year-specific files (e.g. employee_data_2026.json) are merged in.
    Returns: (employees, costs, q_answers, cost_keys)
    """
    # Load base data (2023-2025)
    emp_data = _read_json(bucket, RAW_PREFIX + "employee_data.json") or {"employees": []}
    cost_data = _read_json(bucket, RAW_PREFIX + "cost_data.json") or {"costs": []}
    q_answers_raw = _read_json(bucket, RAW_PREFIX + "questionnaire_answers.json") or []
    cost_key_raw = _read_json(bucket, RAW_PREFIX + "cost_key_data.json") or {"cost_keys": [{}]}

    employees = list(emp_data.get("employees", []))
    costs = list(cost_data.get("costs", []))
    q_answers = list(q_answers_raw) if isinstance(q_answers_raw, list) else []

    # Extract cost key values (use first entry)
    cost_keys = cost_key_raw.get("cost_keys", [{}])[0] if cost_key_raw.get("cost_keys") else {}

    # Discover and merge any year-specific files present in the raw prefix
    # e.g. employee_data_2026.json, cost_data_2026.json, questionnaire_answers_2026.json
    existing_emp_numbers = {e.get("Employee Number") for e in employees}
    existing_cost_numbers = {c.get("employee_number") for c in costs}
    existing_q_numbers = {q.get("employee_number") for q in q_answers}

    for year in range(2026, 2031):
        emp_year = _read_json(bucket, f"{RAW_PREFIX}employee_data_{year}.json")
        if emp_year:
            new_emps = [
                e for e in emp_year.get("employees", [])
                if e.get("Employee Number") not in existing_emp_numbers
            ]
            employees.extend(new_emps)
            existing_emp_numbers.update(e.get("Employee Number") for e in new_emps)
            logger.info("Merged %d employees from year %d", len(new_emps), year)

        cost_year = _read_json(bucket, f"{RAW_PREFIX}cost_data_{year}.json")
        if cost_year:
            new_costs = [
                c for c in cost_year.get("costs", [])
                if c.get("employee_number") not in existing_cost_numbers
            ]
            costs.extend(new_costs)
            existing_cost_numbers.update(c.get("employee_number") for c in new_costs)

        qa_year = _read_json(bucket, f"{RAW_PREFIX}questionnaire_answers_{year}.json")
        if qa_year and isinstance(qa_year, list):
            new_qa = [
                q for q in qa_year
                if q.get("employee_number") not in existing_q_numbers
            ]
            q_answers.extend(new_qa)
            existing_q_numbers.update(q.get("employee_number") for q in new_qa)

    return employees, costs, q_answers, cost_keys


def _build_employee_records(employees, costs, q_answers, cost_keys) -> list[dict]:
    """Join the three datasets into one enriched record per employee."""
    # Index cost and questionnaire data by employee_number for O(1) lookup
    cost_index = {c["employee_number"]: c for c in costs if c.get("employee_number")}
    qa_index = {q["employee_number"]: q for q in q_answers if q.get("employee_number")}

    records = []
    for emp in employees:
        emp_num = emp.get("Employee Number")
        if not emp_num:
            continue

        cost_rec = cost_index.get(emp_num, {})
        qa_rec = qa_index.get(emp_num, {})

        # Calculate actual training cost
        total_cost = _calculate_cost(cost_rec, cost_keys)

        # Build flat answers dict from the answers array
        answers_flat = {}
        numeric_scores = []
        for item in qa_rec.get("answers", []):
            qid = item.get("question_id")
            ans = item.get("answer")
            # Normalise categorical answers
            if qid == "Q8" and isinstance(ans, str):
                ans = ans.strip().title()
            elif qid == "Q11":
                # Normalise to integer 1/0
                if isinstance(ans, str):
                    ans = 1 if ans.strip().lower() in ("yes", "1", "true") else 0
                elif isinstance(ans, bool):
                    ans = int(ans)
                elif ans not in (0, 1):
                    ans = None  # discard invalid values
            elif qid == "Q12" and isinstance(ans, str):
                ans = ans.strip()
            answers_flat[qid] = ans
            # Q1-Q10 and Q9 are numeric; Q8, Q12, Q13, Q14 are text; Q11 is 0/1
            if qid not in ("Q8", "Q12", "Q13", "Q14") and isinstance(ans, (int, float)):
                numeric_scores.append(ans)

        avg_score = round(sum(numeric_scores) / len(numeric_scores), 2) if numeric_scores else None

        records.append({
            "employee_number": emp_num,
            "name": emp.get("Name"),
            "surname": emp.get("Surname"),
            "role": emp.get("Role"),
            "department_code": emp.get("Department Code"),
            "years_experience": emp.get("No. Years Experience"),
            "stream": _normalise_stream(emp.get("Stream")),
            "cloud_type": emp.get("Cloud Type"),
            "year_enrolled": _normalise_year(emp.get("Year Enrolled")),
            "training": {
                "skillbuilder_signed": _to_bool(cost_rec.get("skillbuilder_signed", False)),
                "skillbuilder_completed": _to_bool(cost_rec.get("skillbuilder_completed", False)),
                "instructor_signed": _to_bool(cost_rec.get("instructor_signed", False)),
                "instructor_completed": _to_bool(cost_rec.get("instructor_completed", False)),
                "mytms_signed": _to_bool(cost_rec.get("mytms_signed", False)),
                "mytms_completed": _to_bool(cost_rec.get("mytms_completed", False)),
                "game_day_signed": _to_bool(cost_rec.get("game_day_signed", False)),
                "game_day_completed": _to_bool(cost_rec.get("game_day_completed", False)),
                "hackathon_signed": _to_bool(cost_rec.get("hackathon_signed", False)),
                "hackathon_completed": _to_bool(cost_rec.get("hackathon_completed", False)),
                "received_cert_voucher": cost_rec.get("received_cert_voucher", False),
                "completed_cert_voucher": cost_rec.get("completed_cert_voucher", False),
                "total_cost_eur": total_cost,
            },
            "satisfaction": {
                **answers_flat,
                "avg_numeric_score": avg_score,
            },
        })

    return records


def _aggregate_by_year(records: list[dict]) -> list[dict]:
    buckets: dict[int, dict] = {}

    for rec in records:
        year = rec.get("year_enrolled")
        if not year:
            continue
        if year not in buckets:
            buckets[year] = {
                "year": year,
                "employees": [],
                "total_cost_eur": 0.0,
                "q_scores": {},
                "module_signed": {m: 0 for m in ["skillbuilder", "instructor", "mytms", "game_day", "hackathon", "cert"]},
                "module_completed": {m: 0 for m in ["skillbuilder", "instructor", "mytms", "game_day", "hackathon", "cert"]},
            }
        b = buckets[year]
        b["employees"].append(rec["employee_number"])
        b["total_cost_eur"] += rec["training"]["total_cost_eur"]

        t = rec["training"]
        b["module_signed"]["skillbuilder"] += int(_to_bool(t["skillbuilder_signed"]))
        b["module_completed"]["skillbuilder"] += int(_to_bool(t["skillbuilder_completed"]))
        b["module_signed"]["instructor"] += int(_to_bool(t["instructor_signed"]))
        b["module_completed"]["instructor"] += int(_to_bool(t["instructor_completed"]))
        b["module_signed"]["mytms"] += int(_to_bool(t["mytms_signed"]))
        b["module_completed"]["mytms"] += int(_to_bool(t["mytms_completed"]))
        b["module_signed"]["game_day"] += int(_to_bool(t["game_day_signed"]))
        b["module_completed"]["game_day"] += int(_to_bool(t["game_day_completed"]))
        b["module_signed"]["hackathon"] += int(_to_bool(t["hackathon_signed"]))
        b["module_completed"]["hackathon"] += int(_to_bool(t["hackathon_completed"]))
        b["module_signed"]["cert"] += int(_to_bool(t["received_cert_voucher"]))
        b["module_completed"]["cert"] += int(_to_bool(t["completed_cert_voucher"]))

        for qid in ["Q1", "Q2", "Q3", "Q4", "Q5", "Q6", "Q7", "Q9", "Q10", "Q11"]:
            score = rec["satisfaction"].get(qid)
            if isinstance(score, (int, float)):
                if qid not in b["q_scores"]:
                    b["q_scores"][qid] = []
                b["q_scores"][qid].append(score)

    result = []
    for year, b in sorted(buckets.items()):
        count = len(b["employees"])
        avg_q = {
            qid: round(sum(scores) / len(scores), 2)
            for qid, scores in b["q_scores"].items() if scores
        }
        all_numeric = [v for v in avg_q.values()]
        completion_rates = {}
        for module in b["module_signed"]:
            signed = b["module_signed"][module]
            completed = b["module_completed"][module]
            completion_rates[module] = {
                "signed": signed,
                "completed": completed,
                "rate_pct": round((completed / signed * 100), 1) if signed else 0,
            }
        result.append({
            "year": year,
            "employee_count": count,
            "total_cost_eur": round(b["total_cost_eur"], 2),
            "avg_cost_per_employee_eur": round(b["total_cost_eur"] / count, 2) if count else 0,
            "completion_rates": completion_rates,
            "avg_satisfaction_overall": round(sum(all_numeric) / len(all_numeric), 2) if all_numeric else None,
            "avg_by_question": avg_q,
        })

    return result


def _aggregate_by_stream(records: list[dict]) -> list[dict]:
    buckets: dict[str, dict] = {}

    for rec in records:
        stream = rec.get("stream", "Unknown")
        if stream not in buckets:
            buckets[stream] = {
                "stream": stream,
                "count": 0,
                "total_cost_eur": 0.0,
                "avg_scores": [],
                "completion_counts": 0,
                "total_modules": 0,
            }
        b = buckets[stream]
        b["count"] += 1
        b["total_cost_eur"] += rec["training"]["total_cost_eur"]
        avg = rec["satisfaction"].get("avg_numeric_score")
        if avg is not None:
            b["avg_scores"].append(avg)

        # Count completed modules out of max 5 (excl. hackathon at €0)
        t = rec["training"]
        modules_done = sum([
            int(_to_bool(t["skillbuilder_completed"])),
            int(_to_bool(t["instructor_completed"])),
            int(_to_bool(t["mytms_completed"])),
            int(_to_bool(t["game_day_completed"])),
            int(_to_bool(t["completed_cert_voucher"])),
        ])
        b["completion_counts"] += modules_done
        b["total_modules"] += 5

    result = []
    for stream, b in sorted(buckets.items(), key=lambda x: -x[1]["count"]):
        count = b["count"]
        result.append({
            "stream": stream,
            "employee_count": count,
            "total_cost_eur": round(b["total_cost_eur"], 2),
            "avg_cost_per_employee_eur": round(b["total_cost_eur"] / count, 2) if count else 0,
            "avg_satisfaction": round(sum(b["avg_scores"]) / len(b["avg_scores"]), 2) if b["avg_scores"] else None,
            "avg_module_completion_pct": round(b["completion_counts"] / b["total_modules"] * 100, 1) if b["total_modules"] else 0,
        })

    return result


def _module_overall_stats(records: list[dict]) -> dict:
    modules = {
        "skillbuilder": {"signed": 0, "completed": 0, "cost_eur": DEFAULT_COSTS["skillbuilder"]},
        "instructor": {"signed": 0, "completed": 0, "cost_eur": DEFAULT_COSTS["instructor"]},
        "mytms": {"signed": 0, "completed": 0, "cost_eur": DEFAULT_COSTS["mytms"]},
        "game_day": {"signed": 0, "completed": 0, "cost_eur": DEFAULT_COSTS["game_day"]},
        "hackathon": {"signed": 0, "completed": 0, "cost_eur": DEFAULT_COSTS["hackathon"]},
        "cert": {"signed": 0, "completed": 0, "cost_eur": DEFAULT_COSTS["foundational_cert"]},
    }
    for rec in records:
        t = rec["training"]
        modules["skillbuilder"]["signed"] += int(_to_bool(t["skillbuilder_signed"]))
        modules["skillbuilder"]["completed"] += int(_to_bool(t["skillbuilder_completed"]))
        modules["instructor"]["signed"] += int(_to_bool(t["instructor_signed"]))
        modules["instructor"]["completed"] += int(_to_bool(t["instructor_completed"]))
        modules["mytms"]["signed"] += int(_to_bool(t["mytms_signed"]))
        modules["mytms"]["completed"] += int(_to_bool(t["mytms_completed"]))
        modules["game_day"]["signed"] += int(_to_bool(t["game_day_signed"]))
        modules["game_day"]["completed"] += int(_to_bool(t["game_day_completed"]))
        modules["hackathon"]["signed"] += int(_to_bool(t["hackathon_signed"]))
        modules["hackathon"]["completed"] += int(_to_bool(t["hackathon_completed"]))
        modules["cert"]["signed"] += int(_to_bool(t["received_cert_voucher"]))
        modules["cert"]["completed"] += int(_to_bool(t["completed_cert_voucher"]))

    for m, vals in modules.items():
        s = vals["signed"]
        c = vals["completed"]
        vals["completion_rate_pct"] = round(c / s * 100, 1) if s else 0
        vals["total_spend_eur"] = round(c * vals["cost_eur"], 2)

    return modules


def _categorical_distribution(records: list[dict], question_id: str) -> dict:
    dist: dict[str, int] = {}
    for rec in records:
        val = rec["satisfaction"].get(question_id)
        if val is not None:
            key = str(val)
            dist[key] = dist.get(key, 0) + 1
    return dist


# ── Lambda handler ─────────────────────────────────────────────────────────────

def lambda_handler(event, context):
    # Determine bucket from S3 trigger event or environment variable fallback
    bucket = None
    if event.get("Records"):
        bucket = event["Records"][0]["s3"]["bucket"]["name"]
    else:
        import os
        bucket = os.environ.get("DATA_BUCKET")

    if not bucket:
        raise ValueError("Could not determine S3 bucket from event or DATA_BUCKET env var")

    logger.info("Processing data from bucket: %s", bucket)

    # ── Load ──────────────────────────────────────────────────────────────────
    employees, costs, q_answers, cost_keys = _load_all_data(bucket)
    logger.info(
        "Loaded: %d employees, %d cost records, %d questionnaire responses",
        len(employees), len(costs), len(q_answers)
    )

    # ── Transform ─────────────────────────────────────────────────────────────
    records = _build_employee_records(employees, costs, q_answers, cost_keys)

    # ── Aggregate ─────────────────────────────────────────────────────────────
    by_year = _aggregate_by_year(records)
    by_stream = _aggregate_by_stream(records)
    module_stats = _module_overall_stats(records)
    q8_dist = _categorical_distribution(records, "Q8")   # Most valuable part
    q11_dist = _categorical_distribution(records, "Q11")  # Prefer Platform Academy
    q12_dist = _categorical_distribution(records, "Q12")  # External tools used

    total_cost = round(sum(r["training"]["total_cost_eur"] for r in records), 2)
    all_avg_scores = [r["satisfaction"]["avg_numeric_score"] for r in records if r["satisfaction"]["avg_numeric_score"]]
    overall_avg_satisfaction = round(sum(all_avg_scores) / len(all_avg_scores), 2) if all_avg_scores else None

    # ── Build output ──────────────────────────────────────────────────────────
    output = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "summary": {
            "total_employees": len(records),
            "total_cost_eur": total_cost,
            "years_available": sorted({r["year_enrolled"] for r in records if r["year_enrolled"]}),
            "streams_available": sorted({r["stream"] for r in records if r["stream"]}),
            "avg_satisfaction_overall": overall_avg_satisfaction,
        },
        "by_year": by_year,
        "by_stream": by_stream,
        "module_stats": module_stats,
        "q8_most_valuable": q8_dist,
        "q11_prefer_platform_academy": q11_dist,
        "q12_external_tools": q12_dist,
        "employees": records,
    }

    # ── Write to S3 ───────────────────────────────────────────────────────────
    _write_json(bucket, OUTPUT_KEY, output)

    return {
        "statusCode": 200,
        "body": json.dumps({
            "message": "Processing complete",
            "employees_processed": len(records),
            "output_key": OUTPUT_KEY,
        }),
    }
